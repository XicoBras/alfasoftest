

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row">
        <div class="col">
            <h3>Contacts</h3>
            <hr>
            <div class="my-2">
                
                
                <div class="row">
                  <div class="col-xs-12 col-sm-12 col-md-12">
                        <?php if(Session::has('success')): ?>
                  <div class="alert alert-success">
                        <?php echo e(Session::get('success')); ?>

                  </div>
                        <?php elseif( Session::has('warning')): ?>
                        <div class="alert alert-danger">
                                    <?php echo e(Session::get('warning')); ?>

                              </div>
                  <?php endif; ?> 
                  </div>
            </div>

            </div>

            <hr>
            <?php if($contact->count()===0): ?>
            <p>Dont have a contact's</p>
            <?php else: ?>
            <table class="table table-striped">
                <thead class="thead-dark">
                    <tr>
                        <th>id</th>
                        <th>name</th>
                        <th>contact</th>
                        <th>email</th>
                        <th>edit</th>
                    </tr>

                </thead>

                <tbody>
                    <?php $__currentLoopData = $contact; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($contact->id); ?></td>
                        <td><?php echo e($contact->name); ?></td>
                        <td><?php echo e($contact->contact); ?></td>
                        <td><?php echo e($contact->email); ?></td>
                        <td>
                            <div >
                                 <a href="show_contact/<?php echo e($contact->id); ?>" class="btn btn-success btn-sm far fa-edit" title="Editar Cargo">Show</a>
                                <a href="edit_contact/<?php echo e($contact->id); ?>" class="btn btn-warning btn-sm far fa-edit" title="Editar Cargo">Edit</a>
                                <a href="delete_contact/<?php echo e($contact->id); ?>" class="btn btn-danger btn-sm far fa-edit" title="Editar Cargo">Delete</a>
                                
           
                              
                            </div>
        </div>
        </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

        </table>

        <div>
            <p>Number of Contacts: <?php echo e($contact->count()); ?></p>
        </div>
        <?php endif; ?>
    </div>
</div>
<a href="<?php echo e(route('new_contact')); ?>" class="btn btn-primary"> Create Contact</a>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/home.blade.php ENDPATH**/ ?>