<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row">
        <div class="col">
            <h3>Contacts Project</h3>
            <hr>


<div class="container mt-4">

  <div class="card">
    <div class="card-header text-center font-weight-bold">
       <h3>Edit Contact</h3>
    </div>
     <div class="col-xs-12 col-sm-12 col-md-12" >
                        <?php if($errors->any()): ?>
                      <div class="alert alert-danger">
                
    <?php echo implode('', $errors->all('<div>:message</div>')); ?>

 </div>
 <?php endif; ?>
                  </div>
    <div class="card-body">
      <form name="add-blog-post-form" id="add-blog-post-form" method="post" action="  <?php echo e(route('contact_update')); ?>">
        
       <?php echo csrf_field(); ?>
     
        <div class="form-group">
          <label for="exampleInputEmail1">Name</label>
             <input type="text" id="name" name="name" class="form-control" required="" value="<?php echo e($contact->name); ?>">
             <input type="hidden" id="id" name="id" value="<?php echo e($contact->id); ?>">
    
        </div>
        <div class="form-group">
          <label for="exampleInputEmail1">Contact Number</label>
            
          <input  type="number" id="contact" name="contact"class="form-control" value="<?php echo e($contact->contact); ?>"></input>
        </div>
         <div class="form-group">
          <label for="exampleInputEmail1">Email</label>
        
           <input  type="email" id="email" name="email" class="form-control" value ="<?php echo e($contact->email); ?>" ></input>

        </div>
        <br>
        
        <button type="submit" class="btn btn-primary">Submit</button>
             <a href="javascript:history.back()" class="btn btn-primary"> Back</a>
     
      </form>
    </div>
  </div>
</div>  
</div>






<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/edit.blade.php ENDPATH**/ ?>