<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row">
        <div class="col">
            <h3>Contacts Project</h3>
            <hr>


<div class="container mt-4">

  <div class="card">
    <div class="card-header text-center font-weight-bold">
       <h3>Show Contact</h3>
    </div>
    <div class="card-body">
      <form name="add-blog-post-form" id="add-blog-post-form" method="post" action="">
       <?php echo csrf_field(); ?>
        <div class="form-group">
          <label for="exampleInputEmail1">Name</label>
       
          <text disabled type="text" id="name" name="name" class="form-control"><?php echo e($contact->name); ?></text>
        </div>
        <div class="form-group">
          <label for="exampleInputEmail1">Contact Number</label>
            
          <text disabled type="number" id="contact" name="contact"class="form-control"><?php echo e($contact->contact); ?></text>
        </div>
         <div class="form-group">
          <label for="exampleInputEmail1">Email</label>
        
           <text disabled type="email" id="email" name="email" class="form-control"><?php echo e($contact->email); ?></text>

        </div>
        <br>
        
     
               <a href="../edit_contact/<?php echo e($contact->id); ?>" class="btn btn-warning btn far fa-edit" title="Editar Cargo">Edit</a>
              <a href="../delete_contact/<?php echo e($contact->id); ?>" class="btn btn-danger btn far fa-edit" title="Editar Cargo">Delete</a>
             <a href="javascript:history.back()" class="btn btn-primary"> Back</a>
      </form>
    </div>
  </div>
</div>  
</div>






<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/show.blade.php ENDPATH**/ ?>